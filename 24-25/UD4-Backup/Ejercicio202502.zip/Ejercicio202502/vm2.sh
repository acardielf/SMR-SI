#!/bin/bash

######################################################
GRUPO="CAMBIA AQUÍ TU GRUPO"
######################################################

echo ** Ejecutando script de VM2 de $GRUPO **
######################################################
#### EJECUTA AQUI TODAS LAS ORDENES QUE NECESITES ####
######################################################

echo ** Fin del script de VM2 **